#include "glut.h"
#include <Windows.h>
#include <math.h>
#include <iostream>
using namespace std;

// Global Variable
#define Y 1.0f
#define CPos 0.0f,50.0f,50.0f
#define CCen 0.0f,0.0f,0.0f
#define CUp 0.0f,1.0f,0.0f
#define PKey 80
#define pKey 112
#define OKey 79
#define oKey 111

void display();
void reshape(int _width, int _height);
void idle();
void lighting();
void keyboard(unsigned char key, int x, int y);
void draw_sphere(int r, int stacks, int slices, float* color);

int width = 400, height = 400;
int oflag = 1;
int pflag = 1;
int ER = 0; // Earth rotate speed
float ESR = 0.0f;  // Earth revolution speed
float MR = 0.0f;  // Moon revolution / rotation speed

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowSize(width, height);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("Solar System");

	//set light
	lighting();

	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutIdleFunc(idle);
	glutDisplayFunc(display);

	glutMainLoop();

	return 0;
}

void display()
{
	//ModelView Matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(CPos, CCen, CUp);
	//Projection Matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45, width / (GLfloat)height, 0.1, 1000);
	//Viewport Matrix
	glViewport(0, 0, width, height);
	//
	glMatrixMode(GL_MODELVIEW);
	//glEnable(GL_CULL_FACE);		//remove back face
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);		//normalized normal 
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClearDepth(1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	float orange[4] = { 1.0f, 0.5f, 0.0f, 1.0f };
	float white[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
	float blue[4] = { 0.0f, 0.0f, 1.0f, 1.0f };


	int stacks = 60, slices = 240;

	// Draw the Sun
	draw_sphere(6 * Y, 60, 240, orange);
	
	// Draw the Earth
	glPushMatrix();
	glRotatef(ESR, 0.0f, 1.0f, 0.0f);
	glTranslatef(20.0f, 0.0f, 0.0f);
	glRotatef(ESR, 0.0f, -1.0f, 0.0f);
	glRotatef(23.5f, 0.0f, 0.0f, -1.0f);
	glRotatef(ER, 0.0f, 1.0f, 0.0f);
	glBegin(GL_LINES); // Rotation axis
	glLineWidth(10.0f);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, white);
	glVertex3d(0.0f, 4 * Y, 0.0f);
	glVertex3d(0.0f, -4 * Y, 0.0f);
	glEnd();
	if (oflag == 1) draw_sphere(2 * Y, 180, 360, blue);
	else draw_sphere(2 * Y, 2, 4, blue);
	glPopMatrix();

	// Draw moon
	glPushMatrix();
	glRotatef(ESR, 0, 1, 0);
	glTranslatef(20.0, 0.0, 0.0);
	glRotatef(MR, 0, 1, 0);
	glTranslatef(3.0, 0.0, 0.0);
	draw_sphere(Y, 60, 240, white);
	glPopMatrix();
	glPopMatrix();


	/*
	glPushMatrix();
	glTranslatef(2.0, 0.0, 0.0);
	glRotatef(degree, 0, 1, 0);
	glBegin(GL_TRIANGLES);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, orange);
	glNormal3d(1, 1, 1);
	glVertex3f(1, 0, 0);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, orange);
	glNormal3d(1, 1, 1);
	glVertex3f(0, 1, 0);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, white);
	glNormal3d(1, 1, 1);
	glVertex3f(0, 0, 1);
	glEnd();
	glPopMatrix();

	glutSolidSphere(1, 18, 18);
	*/
	glutSwapBuffers();
}

void reshape(int _width, int _height) {
	width = _width;
	height = _height;
}

void idle() {
	//Sleep(5);
	if (pflag == 1) {
		ER = (ER + 100) % 360;
		ESR = (ESR + 100.0f / 360);
		if (ESR >= 360) ESR -= 360;
		MR = (MR + 100.0f / 28);
		if (MR >= 360) MR -= 360;
	}
	//cout << "ESR: " << ESR << " / MR: " << MR << endl;
	glutPostRedisplay();
}

void lighting()
{
	// enable lighting
	glEnable(GL_LIGHTING);
	//Add directed light
	GLfloat diffuse_color[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat ambient_color[] = { 0.5f, 0.5f, 0.5f, 1.0f };
	GLfloat position[] = { 0.0f, 10.0f, 0.0f, 0.0f };
	glEnable(GL_LIGHT0);								//open light0
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse_color);	//set diffuse color of light0
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient_color);	//set ambient color of light0
	glLightfv(GL_LIGHT0, GL_POSITION, position);		//set position of light 0
}

void keyboard(unsigned char key, int x, int y) {
	switch (key) {
	case oKey:
		oflag *= -1;
		break;
	case OKey:
		oflag *= -1;
		break;
	case pKey:
		pflag *= -1;
		break;
	case PKey:
		pflag *= -1;
		break;
	default:
		break;
	}
}

void draw_sphere(int r, int stacks, int slices, float* color) {
	double PI = 3.141592654;
	for (int j = 0; j < stacks; j++) {
		double latitude1 = (PI / stacks) * j - PI / 2;
		double latitude2 = (PI / stacks) * (j + 1) - PI / 2;
		double sinLat1 = sin(latitude1);
		double cosLat1 = cos(latitude1);
		double sinLat2 = sin(latitude2);
		double cosLat2 = cos(latitude2);
		glBegin(GL_QUAD_STRIP);
		glMaterialfv(GL_FRONT, GL_DIFFUSE, color);
		for (int i = 0; i <= slices; i++) {
			double longitude = (2 * PI / slices) * i;
			double sinLong = sin(longitude);
			double cosLong = cos(longitude);
			double x1 = cosLong * cosLat1;
			double y1 = sinLong * cosLat1;
			double z1 = sinLat1;
			double x2 = cosLong * cosLat2;
			double y2 = sinLong * cosLat2;
			double z2 = sinLat2;
			glNormal3d(x2, y2, z2);
			glVertex3d(r*x2, r*y2, r*z2);
			glNormal3d(x1, y1, z1);
			glVertex3d(r*x1, r*y1, r*z1);
		}
		glEnd();
	}
}