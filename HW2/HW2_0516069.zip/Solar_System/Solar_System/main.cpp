#include "glew.h"
#include "glut.h"
#include "FreeImage.h"
#include <Windows.h>
#include <math.h>
#include <iostream>
using namespace std;

// Global Variable
#define Y 0.75f
#define CPos 0.0f,5.0f,10.0f
#define CCen 0.0f,0.0f,0.0f
#define CUp 0.0f,1.0f,0.0f
#define PKey 80
#define pKey 112
#define OKey 79
#define oKey 111

void display();
void reshape(int _width, int _height);
void idle();
void lighting();
void keyboard(unsigned char key, int x, int y);
void draw_sphere(double r, int stacks, int slices);

int width = 800, height = 800;
int oflag = 1;
int pflag = 1;
int ER = 0; // Earth rotate speed
float ESR = 0.0f;  // Earth revolution speed
float MR = 0.0f;  // Moon revolution / rotation speed

unsigned int textObj;

FIBITMAP* earth;
FIBITMAP* moon;

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowSize(width, height);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("Solar System");

	glewInit();
	glEnable(GL_TEXTURE_2D);
	glGenTextures(1, &textObj);

	//set light
	lighting();

	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutIdleFunc(idle);
	glutDisplayFunc(display);

	earth = FreeImage_ConvertTo32Bits(FreeImage_Load(FreeImage_GetFileType("earth.jpg", 0), "earth.jpg"));
	moon = FreeImage_ConvertTo32Bits(FreeImage_Load(FreeImage_GetFileType("moon.jpg", 0), "moon.jpg"));

	glutMainLoop();

	return 0;
}

void display()
{	
	//ModelView Matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(CPos, CCen, CUp);
	//Projection Matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45, width / (GLfloat)height, 0.1, 1000);
	//Viewport Matrix
	glViewport(0, 0, width, height);
	//
	glMatrixMode(GL_MODELVIEW);
	//glEnable(GL_CULL_FACE);		//remove back face
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);		//normalized normal 
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glDepthFunc(GL_LEQUAL);
	glClearDepth(1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	float white[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
	float blue[4] = { 0.0f, 0.0f, 1.0f, 1.0f };
	
	int eWidth = FreeImage_GetWidth(earth);
	int eHeight = FreeImage_GetHeight(earth);
	int mWidth = FreeImage_GetWidth(moon);
	int mHeight = FreeImage_GetHeight(moon);

	// Draw the Earth
	glPushMatrix();
	glRotatef(23.5f, 0.0f, 0.0f, -1.0f);
	glRotatef(ER, 0.0f, 1.0f, 0.0f);
	glBegin(GL_LINES); // Rotation axis
	glLineWidth(10.0f);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, white);
	glVertex3d(0.0f, 4 * Y, 0.0f);
	glVertex3d(0.0f, -4 * Y, 0.0f);
	glEnd();
	glBindTexture(GL_TEXTURE_2D, textObj);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, eWidth, eHeight, 0, GL_BGRA, GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(earth));
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	if (oflag == 1) draw_sphere(2 * Y, 180, 360);
	else draw_sphere(2 * Y, 2, 4);
	//glBindTexture(GL_TEXTURE_2D, 0);
	glPopMatrix();

	// Draw moon
	glPushMatrix();
	glRotatef(MR, 0, 1, 0);
	glTranslatef(6 * Y, 0.0, 0.0);
	//glBindTexture(GL_TEXTURE_2D, textObj);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, mWidth, mHeight, 0, GL_BGRA, GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(moon));
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	draw_sphere(Y, 60, 240);
	glBindTexture(GL_TEXTURE_2D, 0);
	glPopMatrix();
	glPopMatrix();
	
	glutSwapBuffers();
}

void reshape(int _width, int _height) {
	width = _width;
	height = _height;
}

void idle() {
	//Sleep(5);
	if (pflag == 1) {
		ER = (ER + 100) % 360;
		MR = (MR + 100.0f / 28);
		if (MR >= 360) MR -= 360;
	}
	//cout << "ESR: " << ESR << " / MR: " << MR << endl;
	glutPostRedisplay();
}

void lighting()
{
	// enable lighting
	glEnable(GL_LIGHTING);
	glShadeModel(GL_SMOOTH);
	//Add directed light
	GLfloat diffuse_color[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat ambient_color[] = { 0.5f, 0.5f, 0.5f, 1.0f };
	GLfloat position[] = { 0.0f, 10.0f, 0.0f, 1.0f };
	glEnable(GL_LIGHT0);								//open light0
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse_color);	//set diffuse color of light0
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient_color);	//set ambient color of light0
	glLightfv(GL_LIGHT0, GL_POSITION, position);		//set position of light 0
}

void keyboard(unsigned char key, int x, int y) {
	switch (key) {
	case oKey:
		oflag *= -1;
		break;
	case OKey:
		oflag *= -1;
		break;
	case pKey:
		pflag *= -1;
		break;
	case PKey:
		pflag *= -1;
		break;
	default:
		break;
	}
}

void draw_sphere(double r, int stacks, int slices) {
	double PI = 3.141592654;
	double x, y, z;
	double slice_step = 2 * PI / slices, stack_step = PI / stacks;
	for (int i = 0; i < slices; i++) {
		glBegin(GL_TRIANGLE_STRIP);
		for (int j = 0; j < stacks + 1; j++) {
			x = sin(j * stack_step) * cos(i*slice_step);
			y = cos(j * stack_step);
			z = sin(j * stack_step) * sin(i*slice_step);
			glNormal3d(x, y, z);
			glTexCoord2f(1.0 - (double)i / slices, 1.0 - (double)j / stacks);
			glVertex3d(r*x, r*y, r*z);

			x = sin(j * stack_step) * cos((i + 1)*slice_step);
			y = cos(j * stack_step);
			z = sin(j * stack_step) * sin((i + 1)*slice_step);
			glNormal3d(x, y, z);
			glTexCoord2f(1.0 - (double)(i + 1)  / slices, 1.0 - (double)j / stacks);
			glVertex3d(r*x, r*y, r*z);
		}
		glEnd();
	}
}