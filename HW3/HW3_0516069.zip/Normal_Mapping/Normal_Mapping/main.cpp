#include "glew.h"
#include "glut.h"
#include "FreeImage.h"
#include "shader.h"
#include <Windows.h>
#include <math.h>
#include <iostream>
using namespace std;

// Global Variable
#define Y 0.75f
#define CPos 0.0f,0.0f,3.0f
#define CCen 0.0f,0.0f,0.0f
#define CUp 0.0f,1.0f,0.0f
#define PKey 80
#define pKey 112
#define SLICE 360
#define STACK 180
#define X 5

struct VertexAttribute {
	GLfloat position[3];
	GLfloat normal[3];
	GLfloat texcoord[2];
};

void display();
void reshape(int _width, int _height);
void idle();
void init();
void lighting();
void keyboard(unsigned char key, int x, int y);
VertexAttribute *draw_sphere(double r, int stacks, int slices);

GLuint program;
GLuint vboName;

int width = 800, height = 800;
int flag1 = 1;
int flag2 = 1;
int flag3 = 1;
int pflag = 1;
int ER = 0; // Earth rotate speed
float LR = 0.0f;  // Light revolution speed

unsigned int textObj[3];

FIBITMAP* earth;
FIBITMAP* normal;
FIBITMAP* specular;

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowSize(width, height);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("Solar System");

	glewInit();
	glEnable(GL_TEXTURE_2D);
	glGenTextures(3, textObj);

	//set light
	lighting();

	init();

	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutIdleFunc(idle);
	glutDisplayFunc(display);

	earth = FreeImage_ConvertTo32Bits(FreeImage_Load(FreeImage_GetFileType("earth_texture_map.jpg", 0), "earth_texture_map.jpg"));
	normal = FreeImage_ConvertTo32Bits(FreeImage_Load(FreeImage_GetFileType("earth_normal_map.tif", 0), "earth_normal_map.tif"));
	specular = FreeImage_ConvertTo32Bits(FreeImage_Load(FreeImage_GetFileType("earth_specular_map.tif", 0), "earth_specular_map.tif"));

	glutMainLoop();

	return 0;
}

void display()
{
	//ModelView Matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(CPos, CCen, CUp);
	//Projection Matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45, width / (GLfloat)height, 0.1, 1000);
	//Viewport Matrix
	glViewport(0, 0, width, height);
	//
	glMatrixMode(GL_MODELVIEW);
	//glEnable(GL_CULL_FACE);		//remove back face
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);		//normalized normal 
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glDepthFunc(GL_LEQUAL);
	glClearDepth(1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	float white[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
	float blue[4] = { 0.0f, 0.0f, 1.0f, 1.0f };

	int eWidth = FreeImage_GetWidth(earth);
	int eHeight = FreeImage_GetHeight(earth);
	int nWidth = FreeImage_GetWidth(normal);
	int nHeight = FreeImage_GetHeight(normal);
	int sWidth = FreeImage_GetWidth(specular);
	int sHeight = FreeImage_GetHeight(specular);

	// Draw the Earth
	glPushMatrix();
	glRotatef(23.5f, 0.0f, 0.0f, -1.0f);
	glRotatef(ER, 0.0f, 1.0f, 0.0f);

	GLfloat pmtx[16];
	GLfloat mmtx[16];
	glGetFloatv(GL_PROJECTION_MATRIX, pmtx);
	glGetFloatv(GL_MODELVIEW_MATRIX, mmtx);
	GLint pmatLoc = glGetUniformLocation(program, "Projection");
	GLint mmatLoc = glGetUniformLocation(program, "ModelView");
	GLint textLoc = glGetUniformLocation(program, "Texture");
	GLint normLoc = glGetUniformLocation(program, "Normal");
	GLint specLoc = glGetUniformLocation(program, "Specular");
	GLint flag1Loc = glGetUniformLocation(program, "Flag1");
	GLint flag2Loc = glGetUniformLocation(program, "Flag2");
	GLint flag3Loc = glGetUniformLocation(program, "Flag3");

	glUseProgram(program);

	glUniformMatrix4fv(pmatLoc, 1, GL_FALSE, pmtx);
	glUniformMatrix4fv(mmatLoc, 1, GL_FALSE, mmtx);
	glUniform1i(flag1Loc, flag1);
	glUniform1i(flag2Loc, flag2);
	glUniform1i(flag3Loc, flag3);
	glPopMatrix();

	glPushMatrix();
	glRotatef(LR, 0.0f, 1.0f, 0.0f);
	GLfloat lmmtx[16];
	glGetFloatv(GL_MODELVIEW_MATRIX, lmmtx);
	GLint lmmatLoc = glGetUniformLocation(program, "LightModelView");
	glUniformMatrix4fv(lmmatLoc, 1, GL_FALSE, lmmtx);
	glPopMatrix();


	glActiveTexture(GL_TEXTURE0);
	
	glBindTexture(GL_TEXTURE_2D, textObj[0]);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, eWidth, eHeight, 0, GL_BGRA, GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(earth));
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glUniform1i(textLoc, 0);
	//glBindTexture(GL_TEXTURE_2D, NULL);
	
	glActiveTexture(GL_TEXTURE1);

	glBindTexture(GL_TEXTURE_2D, textObj[1]);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, nWidth, nHeight, 0, GL_BGRA, GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(normal));
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glUniform1i(normLoc, 1);
	//glBindTexture(GL_TEXTURE_2D, NULL);

	glActiveTexture(GL_TEXTURE2);

	glBindTexture(GL_TEXTURE_2D, textObj[2]);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, sWidth, sHeight, 0, GL_BGRA, GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(specular));
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glUniform1i(specLoc, 2);
	//glBindTexture(GL_TEXTURE_2D, NULL);
	
	glDrawArrays(GL_TRIANGLE_STRIP, 0, (STACK + 1)*SLICE*2);
	glUseProgram(0);
	 
	glutSwapBuffers();
}

void init() {
	GLuint vert = createShader("Shaders/example.vert", "vertex");
	GLuint geom = createShader("Shaders/example.geom", "geometry");
	GLuint frag = createShader("Shaders/example.frag", "fragment");
	program = createProgram(vert, geom, frag);

	glGenBuffers(1, &vboName);
	glBindBuffer(GL_ARRAY_BUFFER, vboName);

	VertexAttribute *vertices;
	vertices = draw_sphere(1, STACK, SLICE);
	glBufferData(GL_ARRAY_BUFFER, sizeof(VertexAttribute) * (STACK + 1) * SLICE * 2, vertices, GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexAttribute), (void*)(offsetof(VertexAttribute, position)));
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VertexAttribute), (void*)(offsetof(VertexAttribute, normal)));
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(VertexAttribute), (void*)(offsetof(VertexAttribute, texcoord)));
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void reshape(int _width, int _height) {
	width = _width;
	height = _height;
}

void idle() {
	//Sleep(5);
	if (pflag == 1) {
		ER = (ER + X) % 360;
		LR = fmod((LR + ((float)X/10)), 360);
	}
	//cout << "ESR: " << ESR << " / MR: " << MR << endl;
	glutPostRedisplay();
}

void lighting()
{
	// enable lighting
	glEnable(GL_LIGHTING);
	//glShadeModel(GL_SMOOTH);
	//Add directed light
	GLfloat diffuse_color[] = { 0.35f, 0.3f, 0.35f, 1.0f };
	GLfloat specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat ambient_color[] = { 0.7f, 0.7f, 0.7f, 1.0f };
	GLfloat position[] = { 3.0f, 0.0f, 0.0f, 1.0f };
	glEnable(GL_LIGHT0);								//open light0
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse_color);	//set diffuse color of light0
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient_color);	//set ambient color of light0
	glLightfv(GL_LIGHT0, GL_POSITION, position);		//set position of light 0
}

void keyboard(unsigned char key, int x, int y) {
	switch (key) {
	case '1':
		flag1 *= -1;
		break;
	case '2':
		flag2 *= -1;
		break;
	case '3':
		flag3 *= -1;
		break;
	case pKey:
		pflag *= -1;
		break;
	case PKey:
		pflag *= -1;
		break;
	default:
		break;
	}
}

VertexAttribute * draw_sphere(double r, int stacks, int slices) {
	VertexAttribute *vertices;
	vertices = new VertexAttribute[(stacks+1) * slices * 2];
	int count = 0;
	double PI = 3.141592654;
	double slice_step = 2 * PI / slices, stack_step = PI / stacks;
	for (int i = 0; i < slices; i++) {
		for (int j = 0; j < stacks + 1; j++) {
			vertices[count].position[0] = r * sin(j * stack_step) * cos(i*slice_step);
			vertices[count].normal[0] = sin(j * stack_step) * cos(i*slice_step);
			vertices[count].position[1] = r * cos(j * stack_step);
			vertices[count].normal[1] = cos(j * stack_step);
			vertices[count].position[2] = r * sin(j * stack_step) * sin(i*slice_step);
			vertices[count].normal[2] = sin(j * stack_step) * sin(i*slice_step);
			vertices[count].texcoord[0] = 1.0 - (double)i / slices;
			vertices[count].texcoord[1] = 1.0 - (double)j / stacks;
			count++;

			vertices[count].position[0] = r * sin(j * stack_step) * cos((i + 1)*slice_step);
			vertices[count].normal[0] = sin(j * stack_step) * cos((i + 1)*slice_step);
			vertices[count].position[1] = r * cos(j * stack_step);
			vertices[count].normal[1] = cos(j * stack_step);
			vertices[count].position[2] = r * sin(j * stack_step) * sin((i + 1)*slice_step);
			vertices[count].normal[2] = sin(j * stack_step) * sin((i + 1)*slice_step);
			vertices[count].texcoord[0] = 1.0 - (double)(i + 1) / slices;
			vertices[count].texcoord[1] = 1.0 - (double)j / stacks;
			count++;
		}
	}
	return vertices;
}